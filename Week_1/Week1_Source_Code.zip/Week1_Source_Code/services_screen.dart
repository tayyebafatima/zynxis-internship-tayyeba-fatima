import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import '../widgets/animated_entrance.dart';
import '../widgets/service_card.dart';

/// ==============================================================
/// Services Screen
///
/// WHY THIS CHANGED (Week 5):
/// - `ServiceCard` now actually exists (see widgets/service_card.dart) -
///   this screen would not compile before.
/// - Restored the full services list (Mobile, Web, Cloud, Security) -
///   the original file appeared to be cut off mid-list.
/// - Removed hardcoded dark colors in favor of Theme.of(context), and
///   added a staggered entrance animation per card.
/// ==============================================================
class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final services = <Widget>[
      const ServiceCard(
        icon: Icons.phone_android,
        title: "Mobile Development",
        technologies: ["Flutter", "Android", "iOS", "Cross Platform Apps"],
      ),
      const ServiceCard(
        icon: Icons.language,
        title: "Web Development",
        technologies: ["React", "ASP.NET", "Laravel", "Responsive Design"],
      ),
      const ServiceCard(
        icon: Icons.cloud,
        title: "Cloud Solutions",
        technologies: ["AWS", "Azure", "Firebase", "Cloud Security"],
      ),
      const ServiceCard(
        icon: Icons.security,
        title: "Cyber Security",
        technologies: ["Penetration Testing", "Audits", "Encryption"],
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Our Services")),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("What We Build", style: textTheme.displayLarge),
                  const SizedBox(height: AppConstants.spaceSM),
                  Text(
                    "Professional digital solutions for modern businesses.",
                    style: textTheme.bodyMedium
                        ?.copyWith(color: colorScheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppConstants.spaceSM),
            for (int i = 0; i < services.length; i++)
              AnimatedEntrance(
                delay: Duration(milliseconds: 60 * i),
                child: services[i],
              ),
            const SizedBox(height: AppConstants.spaceLG),
          ],
        ),
      ),
    );
  }
}
