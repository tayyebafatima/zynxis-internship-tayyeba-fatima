import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../models/task.dart';
import '../providers/task_provider.dart';
import '../widgets/task_tile.dart';
import 'report_screen.dart';

// =============================================================
// SIMPLE INTERNAL CANVAS WIDGET
// =============================================================

class SketchPad extends StatefulWidget {
  final Function(String) onSaveDrawing;

  const SketchPad({
    super.key,
    required this.onSaveDrawing,
  });

  @override
  State<SketchPad> createState() => _SketchPadState();
}

class _SketchPadState extends State<SketchPad> {
  List<Offset?> points = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ---------------------------------------------------------
        // DRAWING CANVAS
        // ---------------------------------------------------------
        Container(
          height: 200,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.grey.shade300,
            ),
          ),
          child: GestureDetector(
            onPanUpdate: (details) {
              setState(() {
                final RenderBox renderBox =
                context.findRenderObject() as RenderBox;

                points.add(
                  renderBox.globalToLocal(
                    details.globalPosition,
                  ),
                );
              });
            },
            onPanEnd: (details) {
              setState(() {
                points.add(null);
              });
            },
            child: CustomPaint(
              painter: DrawingPainter(
                points: points,
              ),
              size: Size.infinite,
            ),
          ),
        ),

        // ---------------------------------------------------------
        // CANVAS BUTTONS
        // ---------------------------------------------------------
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton.icon(
              icon: const Icon(
                Icons.clear,
                color: Colors.red,
                size: 18,
              ),
              label: const Text(
                "Clear Canvas",
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
              onPressed: () {
                setState(() {
                  points.clear();
                });
              },
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              icon: const Icon(
                Icons.check,
                size: 18,
              ),
              label: const Text(
                "Save Sketch",
              ),
              onPressed: () {
                widget.onSaveDrawing(
                  "Visual Sketch Vector "
                      "(${points.where((e) => e != null).length} points)",
                );
              },
            ),
          ],
        ),
      ],
    );
  }
}

// =============================================================
// DRAWING PAINTER
// =============================================================

class DrawingPainter extends CustomPainter {
  final List<Offset?> points;

  DrawingPainter({
    required this.points,
  });

  @override
  void paint(
      Canvas canvas,
      Size size,
      ) {
    final Paint paint = Paint()
      ..color = Colors.black
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 4.0;

    for (
    int i = 0;
    i < points.length - 1;
    i++
    ) {
      if (
      points[i] != null &&
          points[i + 1] != null
      ) {
        canvas.drawLine(
          points[i]!,
          points[i + 1]!,
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(
      covariant DrawingPainter oldDelegate,
      ) {
    return true;
  }
}

// =============================================================
// MAIN WORKSPACE MANAGEMENT INTERFACE
// =============================================================

class TaskManagerScreen extends StatefulWidget {
  const TaskManagerScreen({
    super.key,
  });

  @override
  State<TaskManagerScreen> createState() =>
      _TaskManagerScreenState();
}

class _TaskManagerScreenState
    extends State<TaskManagerScreen> {
  TaskType selectedType = TaskType.task;

  final TextEditingController _titleController =
  TextEditingController();

  final TextEditingController _noteContentController =
  TextEditingController();

  double _priorityStars = 1.0;

  String _savedCanvasString = "";

  // =============================================================
  // SUBMIT WORKSPACE ITEM
  // =============================================================

  void _submitItem() {
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Please add a title descriptor first",
          ),
        ),
      );
      return;
    }

    final provider = context.read<TaskProvider>();

    // -----------------------------------------------------------
    // TASK
    // -----------------------------------------------------------
    if (selectedType == TaskType.task) {
      provider.addItem(
        title: _titleController.text.trim(),
        priority: _priorityStars.toInt(),
        type: TaskType.task,
      );
    }

    // -----------------------------------------------------------
    // NOTE
    // -----------------------------------------------------------
    else if (selectedType == TaskType.note) {
      provider.addItem(
        title: _titleController.text.trim(),
        content: _noteContentController.text.trim(),
        type: TaskType.note,
      );
    }

    // -----------------------------------------------------------
    // SKETCH
    // -----------------------------------------------------------
    else if (selectedType == TaskType.sketch) {
      provider.addItem(
        title: _titleController.text.trim(),
        content: _savedCanvasString.isNotEmpty
            ? _savedCanvasString
            : "Empty Drawing Matrix Log",
        type: TaskType.sketch,
      );
    }

    // -----------------------------------------------------------
    // CLEAR FIELDS
    // -----------------------------------------------------------
    _titleController.clear();
    _noteContentController.clear();

    setState(() {
      _priorityStars = 1.0;
      _savedCanvasString = "";
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "Added completely to your ZYNXIS workspace!",
        ),
      ),
    );
  }

  // =============================================================
  // DISPOSE CONTROLLERS
  // =============================================================

  @override
  void dispose() {
    _titleController.dispose();
    _noteContentController.dispose();

    super.dispose();
  }

  // =============================================================
  // BUILD
  // =============================================================

  @override
  Widget build(BuildContext context) {
    final taskProvider = context.watch<TaskProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "ZYNXIS Workspace",
        ),
      ),

      // =========================================================
      // BODY
      // =========================================================

      body: Padding(
        padding: const EdgeInsets.all(
          AppConstants.spaceMD,
        ),

        child: Column(
          children: [
            // ===================================================
            // SCROLLABLE TOP CONTENT
            // ===================================================

            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ===========================================
                    // TASK / NOTE / SKETCH SELECTOR
                    // ===========================================

                    SegmentedButton<TaskType>(
                      segments: const [
                        ButtonSegment(
                          value: TaskType.task,
                          label: Text('Task'),
                          icon: Icon(
                            Icons.assignment,
                          ),
                        ),
                        ButtonSegment(
                          value: TaskType.note,
                          label: Text('Note Pad'),
                          icon: Icon(
                            Icons.note_alt,
                          ),
                        ),
                        ButtonSegment(
                          value: TaskType.sketch,
                          label: Text('Sketch'),
                          icon: Icon(
                            Icons.brush,
                          ),
                        ),
                      ],
                      selected: {
                        selectedType,
                      },
                      onSelectionChanged:
                          (newSelection) {
                        setState(() {
                          selectedType =
                              newSelection.first;
                        });
                      },
                    ),

                    const SizedBox(
                      height: AppConstants.spaceMD,
                    ),

                    // ===========================================
                    // TITLE
                    // ===========================================

                    TextField(
                      controller: _titleController,
                      decoration: const InputDecoration(
                        labelText:
                        "Title / Summary Descriptor",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(
                      height: AppConstants.spaceMD,
                    ),

                    // ===========================================
                    // TASK TYPE CONTENT
                    // ===========================================

                    if (selectedType == TaskType.task) ...[
                      Text(
                        "Select Priority Level: "
                            "${_priorityStars.toInt()} Stars",
                      ),

                      Slider(
                        value: _priorityStars,
                        min: 1,
                        max: 5,
                        divisions: 4,
                        activeColor:
                        AppColors.primary,
                        onChanged: (val) {
                          setState(() {
                            _priorityStars = val;
                          });
                        },
                      ),
                    ]

                    // ===========================================
                    // NOTE
                    // ===========================================

                    else if (
                    selectedType == TaskType.note
                    ) ...[
                        TextField(
                          controller:
                          _noteContentController,
                          maxLines: 4,
                          decoration:
                          const InputDecoration(
                            labelText:
                            "Write your notepad entry "
                                "information directly here...",
                            border:
                            OutlineInputBorder(),
                          ),
                        ),
                      ]

                    // ===========================================
                    // SKETCH
                    // ===========================================

                    else if (
                      selectedType == TaskType.sketch
                      ) ...[
                          SketchPad(
                            onSaveDrawing:
                                (canvasText) {
                              setState(() {
                                _savedCanvasString =
                                    canvasText;
                              });

                              ScaffoldMessenger.of(
                                context,
                              ).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    "Drawing saved! Ready "
                                        "to log workspace item.",
                                  ),
                                ),
                              );
                            },
                          ),
                        ],

                    const SizedBox(
                      height: AppConstants.spaceMD,
                    ),

                    // ===========================================
                    // SAVE WORKSPACE ITEM
                    // ===========================================

                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: _submitItem,
                        style: selectedType ==
                            TaskType.sketch
                            ? ElevatedButton.styleFrom(
                          backgroundColor:
                          Colors.purple,
                        )
                            : null,
                        child: Text(
                          selectedType ==
                              TaskType.sketch
                              ? "Log Saved Sketch Canvas"
                              : "Save Workspace Item",
                          style:
                          selectedType ==
                              TaskType.sketch
                              ? const TextStyle(
                            color: Colors.white,
                          )
                              : null,
                        ),
                      ),
                    ),

                    const SizedBox(
                      height: AppConstants.spaceMD,
                    ),

                    // ===========================================
                    // SUBMIT REPORT - WEEK 8
                    // ===========================================

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(
                          Icons.report,
                        ),
                        label: const Text(
                          'Submit Report',
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                              const ReportScreen(),
                            ),
                          );
                        },
                      ),
                    ),

                    const SizedBox(
                      height: AppConstants.spaceMD,
                    ),

                    const Divider(),

                    const SizedBox(
                      height: AppConstants.spaceSM,
                    ),

                    // ===========================================
                    // TASK LIST
                    // ===========================================

                    if (taskProvider.tasks.isEmpty)
                      const Padding(
                        padding:
                        EdgeInsets.symmetric(
                          vertical: 24,
                        ),
                        child: Center(
                          child: Text(
                            "No workspace items yet.",
                          ),
                        ),
                      )
                    else
                      ListView.builder(
                        shrinkWrap: true,
                        physics:
                        const NeverScrollableScrollPhysics(),
                        itemCount:
                        taskProvider.tasks.length,
                        itemBuilder:
                            (context, index) {
                          final currentTask =
                          taskProvider.tasks[index];

                          return TaskTile(
                            task: currentTask,
                            onCheckboxChanged: () {
                              taskProvider
                                  .toggleTaskCompletion(
                                currentTask.id,
                              );
                            },
                          );
                        },
                      ),

                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}