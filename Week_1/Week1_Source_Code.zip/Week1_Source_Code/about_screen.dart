import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../widgets/animated_entrance.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text("About ZYNXIS"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🎯 FIXED: Changed displayLarge to headlineMedium to match layout constraints
            Text("Who We Are", style: textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: AppConstants.spaceMD),
            AnimatedEntrance(
              child: _buildAboutCard(
                context,
                Icons.business,
                "About ZYNXIS",
                "Zynxis is a software company focused on Mobile Development, "
                    "Artificial Intelligence, Cloud Computing, UI/UX Design and "
                    "Digital Transformation.",
              ),
            ),
            const SizedBox(height: AppConstants.spaceLG),
            Text("Our Mission", style: textTheme.headlineSmall),
            const SizedBox(height: AppConstants.spaceMD),
            AnimatedEntrance(
              delay: const Duration(milliseconds: 100),
              child: _buildAboutCard(
                context,
                Icons.flag,
                "Mission",
                "Deliver high-quality software solutions that empower "
                    "businesses and create digital impact.",
              ),
            ),
            const SizedBox(height: AppConstants.spaceLG),
            Text("Our Vision", style: textTheme.headlineSmall),
            const SizedBox(height: AppConstants.spaceMD),
            AnimatedEntrance(
              delay: const Duration(milliseconds: 200),
              child: _buildAboutCard(
                context,
                Icons.visibility,
                "Vision",
                "Become a leading technology partner worldwide through "
                    "innovation and excellence.",
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutCard(
      BuildContext context,
      IconData icon,
      String title,
      String description,
      ) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: AppColors.primary,
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(height: 15),
            Text(
              title,
              style: textTheme.titleLarge,
            ),
            const SizedBox(height: 10),
            Text(
              description,
              style: textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}