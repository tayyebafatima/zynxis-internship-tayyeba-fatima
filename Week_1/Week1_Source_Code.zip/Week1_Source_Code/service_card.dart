import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_constants.dart';

/// ==============================================================
/// Service Card
///
/// WHY THIS FILE IS NEW (Week 5):
/// ServicesScreen referenced `ServiceCard` but, like FeatureCard, the
/// class was never defined - the Services tab could not have
/// compiled before. Implemented here as a theme-aware, reusable
/// widget with a technology-chip layout.
/// ==============================================================
class ServiceCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final List<String> technologies;

  const ServiceCard({
    super.key,
    required this.icon,
    required this.title,
    required this.technologies,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConstants.spaceMD,
        vertical: AppConstants.spaceSM,
      ),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(AppConstants.spaceMD),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: AppColors.primary.withOpacity(0.15),
                    child: Icon(icon, color: AppColors.primary),
                  ),
                  const SizedBox(width: AppConstants.spaceMD),
                  Expanded(
                    child: Text(title, style: textTheme.titleLarge),
                  ),
                ],
              ),
              const SizedBox(height: AppConstants.spaceMD),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: technologies
                    .map(
                      (tech) => Chip(
                    label: Text(tech),
                    labelStyle: textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                    ),
                    backgroundColor:
                    colorScheme.surfaceContainerHighest,
                    side: BorderSide.none,
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                  ),
                )
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
