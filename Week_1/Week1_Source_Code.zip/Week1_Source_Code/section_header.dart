import 'package:flutter/material.dart';

/// ==============================================================
/// Section Header
///
/// WHY THIS FILE IS NEW (Week 5):
/// Every screen previously repeated the same
/// `Text(..., style: TextStyle(fontSize: 24, fontWeight: bold))`
/// pattern for section titles. This widget standardizes that look
/// and optionally shows a trailing "See All" action, used by the
/// Dashboard's "Recent Tasks" section.
/// ==============================================================
class SectionHeader extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onActionTap;

  const SectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onActionTap,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: textTheme.headlineSmall),
        if (actionLabel != null)
          TextButton(
            onPressed: onActionTap,
            child: Text(actionLabel!),
          ),
      ],
    );
  }
}
