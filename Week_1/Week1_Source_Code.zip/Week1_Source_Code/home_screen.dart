import 'package:flutter/material.dart';
import 'profile_screen.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../utils/responsive.dart';

import '../widgets/animated_entrance.dart';
import '../widgets/feature_card.dart';
import '../widgets/stat_card.dart';

import 'about_screen.dart';
import 'services_screen.dart';
import 'task_manager_screen.dart';

/// ==============================================================
/// Home Screen (Bottom Navigation Shell)
///
/// Week 5:
/// Tab switching uses AnimatedSwitcher for smooth transitions.
///
/// Week 8:
/// Profile is accessible from the top-right of the Home AppBar.
///
/// Week 1:
/// Contact Us button is visible on the Home screen.
///
/// Bottom navigation remains:
/// Home | About | Services | Tasks
/// ==============================================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomePage(),
      const AboutScreen(),
      const ServicesScreen(),
      const TaskManagerScreen(),
    ];

    return Scaffold(
      body: AnimatedSwitcher(
        duration: AppConstants.fastAnimation,
        child: KeyedSubtree(
          key: ValueKey(currentIndex),
          child: pages[currentIndex],
        ),
      ),

      // ==========================================================
      // BOTTOM NAVIGATION
      // ==========================================================
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,

        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: "Home",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.info_outline),
            activeIcon: Icon(Icons.info),
            label: "About",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.design_services_outlined),
            activeIcon: Icon(Icons.design_services),
            label: "Services",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.task_alt_outlined),
            activeIcon: Icon(Icons.task_alt),
            label: "Tasks",
          ),
        ],
      ),
    );
  }
}

/// ==============================================================
/// Home Page
/// The "Home" tab content
/// ==============================================================
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final maxWidth =
    Responsive.maxContentWidth(context);

    return Scaffold(
      // ==========================================================
      // APP BAR
      // Profile button added here for Week 8
      // ==========================================================
      appBar: AppBar(
        title: const Text(
          AppConstants.appName,
        ),

        actions: [
          // ------------------------------------------------------
          // Profile Button
          // ------------------------------------------------------
          IconButton(
            tooltip: 'Profile',

            icon: const Icon(
              Icons.person,
            ),

            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                  const ProfileScreen(),
                ),
              );
            },
          ),
        ],
      ),

      // ==========================================================
      // BODY
      // ==========================================================
      body: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: maxWidth,
          ),

          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                // =================================================
                // HERO BANNER
                // =================================================
                Stack(
                  children: [
                    Container(
                      height: 260,
                      width: double.infinity,

                      decoration:
                      const BoxDecoration(
                        gradient:
                        LinearGradient(
                          colors:
                          AppColors
                              .brandGradient,
                        ),
                      ),
                    ),

                    Container(
                      height: 260,
                      color: Colors.black26,
                    ),

                    Positioned(
                      left: 20,
                      top: 30,
                      bottom: 20,
                      right: 20,

                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,

                        mainAxisAlignment:
                        MainAxisAlignment.end,

                        children: [
                          // -------------------------------------
                          // Logo
                          // -------------------------------------
                          Hero(
                            tag: "app-logo",

                            child: Container(
                              height: 70,
                              width: 70,

                              decoration:
                              BoxDecoration(
                                color: Colors.white
                                    .withOpacity(
                                  0.15,
                                ),
                                shape:
                                BoxShape.circle,
                              ),

                              child: ClipOval(
                                child: Padding(
                                  padding:
                                  const EdgeInsets
                                      .all(12),

                                  child:
                                  Image.asset(
                                    "assets/images/logo.png",

                                    fit: BoxFit
                                        .contain,

                                    errorBuilder:
                                        (
                                        context,
                                        error,
                                        stackTrace,
                                        ) {
                                      return const Icon(
                                        Icons
                                            .flutter_dash,
                                        size: 40,
                                        color: Colors
                                            .white,
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 15,
                          ),

                          // -------------------------------------
                          // Welcome Text
                          // -------------------------------------
                          const Text(
                            "Welcome to ZYNXIS",

                            style: TextStyle(
                              color:
                              Colors.white,
                              fontWeight:
                              FontWeight.bold,
                              fontSize: 26,
                            ),
                          ),

                          const SizedBox(
                            height: 6,
                          ),

                          const Text(
                            "Building Modern Mobile\n"
                                "Applications with Flutter",

                            style: TextStyle(
                              color:
                              Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                // =================================================
                // SPACING
                // =================================================
                Column(
                  children: const [
                    SizedBox(
                      height:
                      AppConstants.spaceLG,
                    ),
                  ],
                ),

                // =================================================
                // STATISTICS
                // =================================================
                Padding(
                  padding:
                  const EdgeInsets.symmetric(
                    horizontal: 15,
                  ),

                  child: Row(
                    children: const [
                      // -------------------------------------------
                      // Projects
                      // -------------------------------------------
                      Expanded(
                        child: StatCard(
                          title: "Projects",
                          value: "120+",
                          icon: Icons
                              .folder_copy_outlined,
                        ),
                      ),

                      SizedBox(
                        width:
                        AppConstants.spaceSM,
                      ),

                      // -------------------------------------------
                      // Clients
                      // -------------------------------------------
                      Expanded(
                        child: StatCard(
                          title: "Clients",
                          value: "50+",
                          icon: Icons
                              .people_outline,
                        ),
                      ),

                      SizedBox(
                        width:
                        AppConstants.spaceSM,
                      ),

                      // -------------------------------------------
                      // Experts
                      // -------------------------------------------
                      Expanded(
                        child: StatCard(
                          title: "Experts",
                          value: "25",
                          icon: Icons
                              .engineering_outlined,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(
                  height:
                  AppConstants.spaceXL,
                ),

                // =================================================
                // CONTACT US - WEEK 1
                // =================================================
                Padding(
                  padding:
                  const EdgeInsets.symmetric(
                    horizontal: 20,
                  ),

                  child: SizedBox(
                    width: double.infinity,

                    child:
                    ElevatedButton.icon(
                      onPressed: () {
                        ScaffoldMessenger.of(
                          context,
                        ).showSnackBar(
                          const SnackBar(
                            content: Text(
                              "Contact Us action selected.",
                            ),
                          ),
                        );
                      },

                      icon: const Icon(
                        Icons.contact_mail,
                      ),

                      label: const Text(
                        'Contact Us',
                      ),
                    ),
                  ),
                ),

                const SizedBox(
                  height:
                  AppConstants.spaceXL,
                ),

                // =================================================
                // FEATURES SECTION
                // =================================================
                Padding(
                  padding:
                  const EdgeInsets.only(
                    left: 20,
                  ),

                  child: Align(
                    alignment:
                    Alignment.centerLeft,

                    child: Text(
                      "Our Features",

                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall,
                    ),
                  ),
                ),

                const SizedBox(
                  height:
                  AppConstants.spaceSM,
                ),

                // =================================================
                // FEATURE CARD 1
                // =================================================
                AnimatedEntrance(
                  delay: const Duration(
                    milliseconds: 60,
                  ),

                  child:
                  const FeatureCard(
                    icon:
                    Icons.phone_android,

                    title:
                    "Mobile Development",

                    subtitle:
                    "Beautiful Flutter applications for Android and iOS.",
                  ),
                ),

                // =================================================
                // FEATURE CARD 2
                // =================================================
                AnimatedEntrance(
                  delay: const Duration(
                    milliseconds: 120,
                  ),

                  child:
                  const FeatureCard(
                    icon:
                    Icons.cloud_outlined,

                    title:
                    "Cloud Solutions",

                    subtitle:
                    "Scalable cloud infrastructure for modern businesses.",
                  ),
                ),

                // =================================================
                // FEATURE CARD 3
                // =================================================
                AnimatedEntrance(
                  delay: const Duration(
                    milliseconds: 180,
                  ),

                  child:
                  const FeatureCard(
                    icon:
                    Icons.security,

                    title:
                    "Cyber Security",

                    subtitle:
                    "Protecting applications using modern security practices.",
                  ),
                ),

                const SizedBox(
                  height:
                  AppConstants.spaceLG,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}