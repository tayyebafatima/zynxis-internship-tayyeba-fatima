import 'package:flutter/material.dart';
import '../models/task.dart';

class TaskProvider with ChangeNotifier {
  final List<SimpleTask> _tasks = [];

  List<SimpleTask> get tasks => _tasks;

  // --- NEW GETTERS AND METHODS FOR DASHBOARD COMPATIBILITY ---

  // Total number of items tracked in workspace
  int get totalCount => _tasks.length;

  // Total completed regular tasks
  int get completedCount => _tasks.where((item) => item.type == TaskType.task && item.isCompleted).length;

  // Progress percentage (between 0.0 and 1.0)
  double get progress {
    final totalTasksCount = _tasks.where((item) => item.type == TaskType.task).length;
    if (totalTasksCount == 0) return 0.0;
    return completedCount / totalTasksCount;
  }

  // Returns the latest 3 elements to keep the dashboard tidy
  List<SimpleTask> recent() {
    return _tasks.take(3).toList();
  }

  // Legacy fallback pointer connecting back to your original method
  void toggleTask(String id, bool val) {
    toggleTaskCompletion(id);
  }

  // Deletes an entry out of the workspace collection completely
  void deleteTask(String id) {
    _tasks.removeWhere((item) => item.id == id);
    notifyListeners();
  }
  // -----------------------------------------------------------

  void addItem({
    required String title,
    int priority = 1,
    String content = '',
    required TaskType type,
  }) {
    final newItem = SimpleTask(
      id: DateTime.now().toString(),
      title: title,
      priority: priority,
      content: content,
      type: type,
      createdAt: DateTime.now(),
    );
    _tasks.insert(0, newItem);
    notifyListeners();
  }

  void toggleTaskCompletion(String id) {
    final index = _tasks.indexWhere((task) => task.id == id);
    if (index != -1) {
      _tasks[index] = _tasks[index].copyWith(isCompleted: !_tasks[index].isCompleted);
      notifyListeners();
    }
  }
}