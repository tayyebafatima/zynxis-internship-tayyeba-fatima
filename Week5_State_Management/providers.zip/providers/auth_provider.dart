import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? _user;
  bool _isLoading = false;
  bool _rememberMe = false;


  // ===========================
  // Getters
  // ===========================

  bool get isLoggedIn => _user != null;

  String get username => _user?.email ?? "";

  bool get isLoading => _isLoading;

  bool get rememberMe => _rememberMe;

  User? get currentUser => _user;



  // ===========================
  // Load Existing Session
  // ===========================

  Future<void> loadSession() async {

    _isLoading = true;
    notifyListeners();


    _user = _auth.currentUser;


    _auth.authStateChanges().listen((User? user) {

      _user = user;

      notifyListeners();

    });


    _isLoading = false;
    notifyListeners();
  }



  // ===========================
  // Login
  // ===========================

  Future<bool> login({

    required String username,

    required String password,

    required bool rememberMe,

  }) async {


    _isLoading = true;

    notifyListeners();



    try {


      UserCredential result =
      await _auth.signInWithEmailAndPassword(

        email: username.trim(),

        password: password.trim(),

      );



      _user = result.user;

      _rememberMe = rememberMe;



      _isLoading = false;

      notifyListeners();



      debugPrint(
          "Login Successful: ${_user?.email}"
      );


      return true;



    } on FirebaseAuthException catch(e) {


      _isLoading = false;

      notifyListeners();


      debugPrint(
          "Login Error: ${e.code} - ${e.message}"
      );


      return false;



    } catch(e) {


      _isLoading = false;

      notifyListeners();


      debugPrint(
          "Unexpected Error: $e"
      );


      return false;

    }

  }




  // ===========================
  // Register
  // ===========================

  Future<bool> register({

    required String email,

    required String password,

  }) async {


    _isLoading = true;

    notifyListeners();



    try {


      UserCredential result =
      await _auth.createUserWithEmailAndPassword(

        email: email.trim(),

        password: password.trim(),

      );



      _user = result.user;



      _isLoading = false;

      notifyListeners();



      debugPrint(
          "Registration Successful"
      );


      return true;



    } on FirebaseAuthException catch(e) {


      _isLoading = false;

      notifyListeners();


      debugPrint(
          "Register Error: ${e.code} - ${e.message}"
      );


      return false;

    }

  }





  // ===========================
  // Password Reset
  // ===========================

  Future<void> sendPasswordResetEmail(
      String email
      ) async {


    try {


      await _auth.sendPasswordResetEmail(

        email: email.trim(),

      );


      debugPrint(
          "Password reset email sent"
      );



    } on FirebaseAuthException catch(e) {


      debugPrint(
          "Password Reset Error: ${e.code} - ${e.message}"
      );


      rethrow;

    }

  }





  // ===========================
  // Logout
  // ===========================

  Future<void> logout() async {


    _isLoading = true;

    notifyListeners();



    await _auth.signOut();



    _user = null;



    _isLoading = false;

    notifyListeners();

  }

}