import 'package:flutter/material.dart';

import '../models/favorite_user.dart';
import '../services/database_service.dart';

class FavoriteProvider with ChangeNotifier {
  // ------------------------------------------------------------
  // FAVORITES LIST
  // ------------------------------------------------------------
  final List<FavoriteUser> _favorites = [];

  bool _isLoaded = false;

  // ------------------------------------------------------------
  // GETTERS
  // ------------------------------------------------------------
  List<FavoriteUser> get favorites =>
      List.unmodifiable(_favorites);

  int get totalCount => _favorites.length;

  // ------------------------------------------------------------
  // LOAD FAVORITES FROM SQLITE
  // ------------------------------------------------------------
  Future<void> loadFavorites() async {
    if (_isLoaded) return;

    try {
      final List<FavoriteUser> saved =
      await DatabaseService.instance.getAllFavorites();

      _favorites
        ..clear()
        ..addAll(saved);

      _isLoaded = true;

      notifyListeners();
    } catch (e) {
      debugPrint(
        'Error loading favorites from SQLite: $e',
      );

      _isLoaded = false;

      notifyListeners();
    }
  }

  // ------------------------------------------------------------
  // CHECK WHETHER USER IS FAVORITE
  // ------------------------------------------------------------
  bool isFavorite(int id) {
    return _favorites.any(
          (user) => user.id == id,
    );
  }

  // ------------------------------------------------------------
  // ADD / REMOVE FAVORITE
  // ------------------------------------------------------------
  Future<void> toggleFavorite(FavoriteUser user) async {
    final bool exists = isFavorite(user.id);

    // Update UI immediately.
    if (exists) {
      _favorites.removeWhere(
            (item) => item.id == user.id,
      );
    } else {
      _favorites.add(user);
    }

    notifyListeners();

    // Save change to SQLite.
    try {
      if (exists) {
        await DatabaseService.instance.deleteFavorite(
          user.id,
        );
      } else {
        await DatabaseService.instance.insertFavorite(
          user,
        );
      }
    } catch (e) {
      debugPrint(
        'Error updating SQLite favorite status: $e',
      );

      // Roll back UI if database operation fails.
      if (exists) {
        if (!isFavorite(user.id)) {
          _favorites.add(user);
        }
      } else {
        _favorites.removeWhere(
              (item) => item.id == user.id,
        );
      }

      notifyListeners();
    }
  }

  // ------------------------------------------------------------
  // REMOVE FAVORITE
  // ------------------------------------------------------------
  Future<void> removeFavorite(int id) async {
    final int index = _favorites.indexWhere(
          (user) => user.id == id,
    );

    if (index == -1) return;

    final FavoriteUser removedUser =
    _favorites[index];

    _favorites.removeAt(index);
    notifyListeners();

    try {
      await DatabaseService.instance.deleteFavorite(id);
    } catch (e) {
      debugPrint(
        'Error removing favorite from SQLite: $e',
      );

      _favorites.insert(
        index,
        removedUser,
      );

      notifyListeners();
    }
  }

  // ------------------------------------------------------------
  // CLEAR ALL FAVORITES
  // ------------------------------------------------------------
  Future<void> clearFavorites() async {
    final List<FavoriteUser> oldFavorites =
    List<FavoriteUser>.from(_favorites);

    _favorites.clear();
    notifyListeners();

    try {
      for (final FavoriteUser user in oldFavorites) {
        await DatabaseService.instance.deleteFavorite(
          user.id,
        );
      }
    } catch (e) {
      debugPrint(
        'Error clearing favorites from SQLite: $e',
      );

      _favorites
        ..clear()
        ..addAll(oldFavorites);

      notifyListeners();
    }
  }

  // ------------------------------------------------------------
  // FORCE RELOAD FROM SQLITE
  // ------------------------------------------------------------
  Future<void> reloadFavorites() async {
    try {
      final List<FavoriteUser> saved =
      await DatabaseService.instance.getAllFavorites();

      _favorites
        ..clear()
        ..addAll(saved);

      _isLoaded = true;

      notifyListeners();
    } catch (e) {
      debugPrint(
        'Error reloading favorites from SQLite: $e',
      );
    }
  }
}