import 'package:flutter/material.dart';
import '../services/preference_service.dart';

/// ==============================================================
/// Theme Provider
///
/// Manages the application's theme using Provider (ChangeNotifier)
/// and persists the selected theme using SharedPreferences.
///
/// WHY THIS CHANGED (Week 5):
/// Logic is unchanged from before (it was already solid) - only
/// comments and formatting were cleaned up. The actual "beautiful
/// animated switch" now comes from `MaterialApp.themeAnimationDuration`
/// in main.dart, which cross-fades every color automatically whenever
/// this provider calls notifyListeners(). No extra animation code is
/// needed inside this class.
/// ==============================================================
class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.dark;

  ThemeMode get themeMode => _themeMode;

  bool get isDarkMode => _themeMode == ThemeMode.dark;

  /// Loads the previously saved theme from disk. Called once on
  /// app startup before runApp().
  Future<void> loadTheme() async {
    final isDark = await PreferenceService.getTheme();
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }

  /// Toggles between Light and Dark, then saves the choice.
  Future<void> toggleTheme(bool isDark) async {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    await PreferenceService.saveTheme(isDark);
    notifyListeners();
  }
}
